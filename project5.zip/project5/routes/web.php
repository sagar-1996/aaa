<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PhotoController;
use App\Http\Controllers\Prohect5Controller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/users', 'App\Http\Controllers\Prohect5Controller@show');
Route::get('delete/{id}', 'App\Http\Controllers\Prohect5Controller@destroy');
Route::get('AddRecord', 'App\Http\Controllers\Prohect5Controller@create');
Route::post('create1', 'App\Http\Controllers\Prohect5Controller@store');
Route::get('Edit1/{id}', 'App\Http\Controllers\Prohect5Controller@edit');
Route::post('update1/{id}', 'App\Http\Controllers\Prohect5Controller@update')->name('sagar.update');
//Route::resource('photo', 'App\Http\Controllers\PhotoController', ['except' => ['index']]);

$('#button1').click(function(){
    $('#content').load('create.blade.php')
} );
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script type="/javascript" src="file:///public/javascripts/receiver.js"></script>


  
    <style>
         button {width:100px;}
</style>
</head>
<body>

<div>
<button class="btn w3-light-blue"style="font-size:30px;width:100%" id="button1"><a href="AddRecord">Add Record</a><br></button><br><br>
<?php echo e(session('msg')); ?>

  <table class='table table-dark table-hover'>
  <tr>
  <td>id </td>
  <td>name</td>
  <td>Action</td>
  </tr>
  <?php $__currentLoopData = $sagarArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sagar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
  <td><?php echo e($sagar->id); ?> </td>
  <td><?php echo e($sagar->name); ?></td>
  <td><?php echo e($sagar->name2); ?></td>
  <td>
  <button class='btn btn-warning'><a href="Edit1/<?php echo e($sagar->id); ?>">Edit</a></button>
  <button class="btn btn-danger"><a href="delete/<?php echo e($sagar->id); ?>">Delete</a></button>
   </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <table>
  <div id="content">
  </div>

  <script>

  $('#button1').click(function(){
      $('#content').load('create.blade.php')
    } );

  </script>
</body>
</html><?php /**PATH C:\Users\Admin\Desktop\project5\resources\views/project-show.blade.php ENDPATH**/ ?>
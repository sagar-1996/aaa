<?php

namespace App\Http\Controllers;

use App\Models\prohect5;
use Illuminate\Http\Request;

class Prohect5Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('project-show');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $res=new prohect5;
        $res -> name=$request->input('name');
        $res->save();

        $request ->session()->flash('msg','data sumbimmited');
        return redirect("users");

    }

    
    public function show(prohect5 $prohect5)
    {
        return view('project-show')-> with('sagarArr',$prohect5::all());;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\prohect5  $prohect5
     * @return \Illuminate\Http\Response
     */
    public function edit(prohect5 $prohect5,$id)
    {
        return view("Edit")->with('sagarArr',prohect5::find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\prohect5  $prohect5
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, prohect5 $prohect5)
    {
        $res=prohect5::find($request->id);
        $res->name=$request->input('name');
        $res->save();

        $request ->session()->flash('msg','data sumbimmited');
        return redirect("users");

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\prohect5  $prohect5
     * @return \Illuminate\Http\Response
     */
    public function destroy(prohect5 $prohect5,$id)
    {
        prohect5::destroy(array('id',$id));

        return redirect('users');
    }
}
